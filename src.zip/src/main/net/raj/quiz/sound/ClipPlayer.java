/*
 * Created on Sep 3, 2005
 */
 
package net.raj.quiz.sound;

/**
 * @author Rajkumar
 */
public class ClipPlayer {

    public static void main(String[] args) 
    {
    }
}
